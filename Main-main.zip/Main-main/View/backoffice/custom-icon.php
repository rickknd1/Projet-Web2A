<!DOCTYPE html>
<html>
	<head>
		<!-- Basic Page Info -->
		<meta charset="utf-8" />
		<title>DeskApp - Bootstrap Admin Dashboard HTML Template</title>

		<!-- Site favicon -->
		<link
			rel="apple-touch-icon"
			sizes="180x180"
			href="vendors/images/apple-touch-icon.png"
		/>
		<link
			rel="icon"
			type="image/png"
			sizes="32x32"
			href="vendors/images/favicon-32x32.png"
		/>
		<link
			rel="icon"
			type="image/png"
			sizes="16x16"
			href="vendors/images/favicon-16x16.png"
		/>

		<!-- Mobile Specific Metas -->
		<meta
			name="viewport"
			content="width=device-width, initial-scale=1, maximum-scale=1"
		/>

		<!-- Google Font -->
		<link
			href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
			rel="stylesheet"
		/>
		<!-- CSS -->
		<link rel="stylesheet" type="text/css" href="vendors/styles/core.css" />
		<link
			rel="stylesheet"
			type="text/css"
			href="vendors/styles/icon-font.min.css"
		/>
		<link rel="stylesheet" type="text/css" href="vendors/styles/style.css" />

		<!-- Global site tag (gtag.js) - Google Analytics -->
		<script
			async
			src="https://www.googletagmanager.com/gtag/js?id=G-GBZ3SGGX85"
		></script>
		<script
			async
			src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2973766580778258"
			crossorigin="anonymous"
		></script>
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag() {
				dataLayer.push(arguments);
			}
			gtag("js", new Date());

			gtag("config", "G-GBZ3SGGX85");
		</script>
		<!-- Google Tag Manager -->
		<script>
			(function (w, d, s, l, i) {
				w[l] = w[l] || [];
				w[l].push({ "gtm.start": new Date().getTime(), event: "gtm.js" });
				var f = d.getElementsByTagName(s)[0],
					j = d.createElement(s),
					dl = l != "dataLayer" ? "&l=" + l : "";
				j.async = true;
				j.src = "https://www.googletagmanager.com/gtm.js?id=" + i + dl;
				f.parentNode.insertBefore(j, f);
			})(window, document, "script", "dataLayer", "GTM-NXZMQSS");
		</script>
		<!-- End Google Tag Manager -->
	</head>
	<body>
		<div class="pre-loader">
			<div class="pre-loader-box">
				<div class="loader-logo">
					<img src="vendors/images/deskapp-logo.svg" alt="" />
				</div>
				<div class="loader-progress" id="progress_div">
					<div class="bar" id="bar1"></div>
				</div>
				<div class="percent" id="percent1">0%</div>
				<div class="loading-text">Loading...</div>
			</div>
		</div>

		<div class="header">
			<div class="header-left">
				<div class="menu-icon bi bi-list"></div>
				<div
					class="search-toggle-icon bi bi-search"
					data-toggle="header_search"
				></div>
				<div class="header-search">
					<form>
						<div class="form-group mb-0">
							<i class="dw dw-search2 search-icon"></i>
							<input
								type="text"
								class="form-control search-input"
								placeholder="Search Here"
							/>
							<div class="dropdown">
								<a
									class="dropdown-toggle no-arrow"
									href="#"
									role="button"
									data-toggle="dropdown"
								>
									<i class="ion-arrow-down-c"></i>
								</a>
								<div class="dropdown-menu dropdown-menu-right">
									<div class="form-group row">
										<label class="col-sm-12 col-md-2 col-form-label"
											>From</label
										>
										<div class="col-sm-12 col-md-10">
											<input
												class="form-control form-control-sm form-control-line"
												type="text"
											/>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-sm-12 col-md-2 col-form-label">To</label>
										<div class="col-sm-12 col-md-10">
											<input
												class="form-control form-control-sm form-control-line"
												type="text"
											/>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-sm-12 col-md-2 col-form-label"
											>Subject</label
										>
										<div class="col-sm-12 col-md-10">
											<input
												class="form-control form-control-sm form-control-line"
												type="text"
											/>
										</div>
									</div>
									<div class="text-right">
										<button class="btn btn-primary">Search</button>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class="header-right">
				<div class="dashboard-setting user-notification">
					<div class="dropdown">
						<a
							class="dropdown-toggle no-arrow"
							href="javascript:;"
							data-toggle="right-sidebar"
						>
							<i class="dw dw-settings2"></i>
						</a>
					</div>
				</div>
				<div class="user-notification">
					<div class="dropdown">
						<a
							class="dropdown-toggle no-arrow"
							href="#"
							role="button"
							data-toggle="dropdown"
						>
							<i class="icon-copy dw dw-notification"></i>
							<span class="badge notification-active"></span>
						</a>
						<div class="dropdown-menu dropdown-menu-right">
							<div class="notification-list mx-h-350 customscroll">
								<ul>
									<li>
										<a href="#">
											<img src="vendors/images/img.jpg" alt="" />
											<h3>John Doe</h3>
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing
												elit, sed...
											</p>
										</a>
									</li>
									<li>
										<a href="#">
											<img src="vendors/images/photo1.jpg" alt="" />
											<h3>Lea R. Frith</h3>
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing
												elit, sed...
											</p>
										</a>
									</li>
									<li>
										<a href="#">
											<img src="vendors/images/photo2.jpg" alt="" />
											<h3>Erik L. Richards</h3>
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing
												elit, sed...
											</p>
										</a>
									</li>
									<li>
										<a href="#">
											<img src="vendors/images/photo3.jpg" alt="" />
											<h3>John Doe</h3>
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing
												elit, sed...
											</p>
										</a>
									</li>
									<li>
										<a href="#">
											<img src="vendors/images/photo4.jpg" alt="" />
											<h3>Renee I. Hansen</h3>
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing
												elit, sed...
											</p>
										</a>
									</li>
									<li>
										<a href="#">
											<img src="vendors/images/img.jpg" alt="" />
											<h3>Vicki M. Coleman</h3>
											<p>
												Lorem ipsum dolor sit amet, consectetur adipisicing
												elit, sed...
											</p>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="user-info-dropdown">
					<div class="dropdown">
						<a
							class="dropdown-toggle"
							href="#"
							role="button"
							data-toggle="dropdown"
						>
							<span class="user-icon">
								<img src="vendors/images/photo1.jpg" alt="" />
							</span>
							<span class="user-name">Ross C. Lopez</span>
						</a>
						<div
							class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list"
						>
							<a class="dropdown-item" href="profile.html"
								><i class="dw dw-user1"></i> Profile</a
							>
							<a class="dropdown-item" href="profile.html"
								><i class="dw dw-settings2"></i> Setting</a
							>
							<a class="dropdown-item" href="faq.html"
								><i class="dw dw-help"></i> Help</a
							>
							<a class="dropdown-item" href="login.html"
								><i class="dw dw-logout"></i> Log Out</a
							>
						</div>
					</div>
				</div>
				<div class="github-link">
					<a href="https://github.com/dropways/deskapp" target="_blank"
						><img src="vendors/images/github.svg" alt=""
					/></a>
				</div>
			</div>
		</div>

		<div class="right-sidebar">
			<div class="sidebar-title">
				<h3 class="weight-600 font-16 text-blue">
					Layout Settings
					<span class="btn-block font-weight-400 font-12"
						>User Interface Settings</span
					>
				</h3>
				<div class="close-sidebar" data-toggle="right-sidebar-close">
					<i class="icon-copy ion-close-round"></i>
				</div>
			</div>
			<div class="right-sidebar-body customscroll">
				<div class="right-sidebar-body-content">
					<h4 class="weight-600 font-18 pb-10">Header Background</h4>
					<div class="sidebar-btn-group pb-30 mb-10">
						<a
							href="javascript:void(0);"
							class="btn btn-outline-primary header-white active"
							>White</a
						>
						<a
							href="javascript:void(0);"
							class="btn btn-outline-primary header-dark"
							>Dark</a
						>
					</div>

					<h4 class="weight-600 font-18 pb-10">Sidebar Background</h4>
					<div class="sidebar-btn-group pb-30 mb-10">
						<a
							href="javascript:void(0);"
							class="btn btn-outline-primary sidebar-light"
							>White</a
						>
						<a
							href="javascript:void(0);"
							class="btn btn-outline-primary sidebar-dark active"
							>Dark</a
						>
					</div>

					<h4 class="weight-600 font-18 pb-10">Menu Dropdown Icon</h4>
					<div class="sidebar-radio-group pb-10 mb-10">
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebaricon-1"
								name="menu-dropdown-icon"
								class="custom-control-input"
								value="icon-style-1"
								checked=""
							/>
							<label class="custom-control-label" for="sidebaricon-1"
								><i class="fa fa-angle-down"></i
							></label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebaricon-2"
								name="menu-dropdown-icon"
								class="custom-control-input"
								value="icon-style-2"
							/>
							<label class="custom-control-label" for="sidebaricon-2"
								><i class="ion-plus-round"></i
							></label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebaricon-3"
								name="menu-dropdown-icon"
								class="custom-control-input"
								value="icon-style-3"
							/>
							<label class="custom-control-label" for="sidebaricon-3"
								><i class="fa fa-angle-double-right"></i
							></label>
						</div>
					</div>

					<h4 class="weight-600 font-18 pb-10">Menu List Icon</h4>
					<div class="sidebar-radio-group pb-30 mb-10">
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebariconlist-1"
								name="menu-list-icon"
								class="custom-control-input"
								value="icon-list-style-1"
								checked=""
							/>
							<label class="custom-control-label" for="sidebariconlist-1"
								><i class="ion-minus-round"></i
							></label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebariconlist-2"
								name="menu-list-icon"
								class="custom-control-input"
								value="icon-list-style-2"
							/>
							<label class="custom-control-label" for="sidebariconlist-2"
								><i class="fa fa-circle-o" aria-hidden="true"></i
							></label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebariconlist-3"
								name="menu-list-icon"
								class="custom-control-input"
								value="icon-list-style-3"
							/>
							<label class="custom-control-label" for="sidebariconlist-3"
								><i class="dw dw-check"></i
							></label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebariconlist-4"
								name="menu-list-icon"
								class="custom-control-input"
								value="icon-list-style-4"
								checked=""
							/>
							<label class="custom-control-label" for="sidebariconlist-4"
								><i class="icon-copy dw dw-next-2"></i
							></label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebariconlist-5"
								name="menu-list-icon"
								class="custom-control-input"
								value="icon-list-style-5"
							/>
							<label class="custom-control-label" for="sidebariconlist-5"
								><i class="dw dw-fast-forward-1"></i
							></label>
						</div>
						<div class="custom-control custom-radio custom-control-inline">
							<input
								type="radio"
								id="sidebariconlist-6"
								name="menu-list-icon"
								class="custom-control-input"
								value="icon-list-style-6"
							/>
							<label class="custom-control-label" for="sidebariconlist-6"
								><i class="dw dw-next"></i
							></label>
						</div>
					</div>

					<div class="reset-options pt-30 text-center">
						<button class="btn btn-danger" id="reset-settings">
							Reset Settings
						</button>
					</div>
				</div>
			</div>
		</div>

		<div class="left-side-bar">
			<div class="brand-logo">
				<a href="index.html">
					<img src="vendors/images/deskapp-logo.svg" alt="" class="dark-logo" />
					<img
						src="vendors/images/deskapp-logo-white.svg"
						alt=""
						class="light-logo"
					/>
				</a>
				<div class="close-sidebar" data-toggle="left-sidebar-close">
					<i class="ion-close-round"></i>
				</div>
			</div>
			<div class="menu-block customscroll">
				<div class="sidebar-menu">
					<ul id="accordion-menu">
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-house"></span
								><span class="mtext">Home</span>
							</a>
							<ul class="submenu">
								<li><a href="index.html">Dashboard style 1</a></li>
								<li><a href="index2.html">Dashboard style 2</a></li>
								<li><a href="index3.html">Dashboard style 3</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-textarea-resize"></span
								><span class="mtext">Forms</span>
							</a>
							<ul class="submenu">
								<li><a href="form-basic.html">Form Basic</a></li>
								<li>
									<a href="advanced-components.html">Advanced Components</a>
								</li>
								<li><a href="form-wizard.html">Form Wizard</a></li>
								<li><a href="html5-editor.html">HTML5 Editor</a></li>
								<li><a href="form-pickers.html">Form Pickers</a></li>
								<li><a href="image-cropper.html">Image Cropper</a></li>
								<li><a href="image-dropzone.html">Image Dropzone</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-table"></span
								><span class="mtext">Tables</span>
							</a>
							<ul class="submenu">
								<li><a href="basic-table.html">Basic Tables</a></li>
								<li><a href="datatable.html">DataTables</a></li>
							</ul>
						</li>
						<li>
							<a href="calendar.html" class="dropdown-toggle no-arrow">
								<span class="micon bi bi-calendar4-week"></span
								><span class="mtext">Calendar</span>
							</a>
						</li>
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-archive"></span
								><span class="mtext"> UI Elements </span>
							</a>
							<ul class="submenu">
								<li><a href="ui-buttons.html">Buttons</a></li>
								<li><a href="ui-cards.html">Cards</a></li>
								<li><a href="ui-cards-hover.html">Cards Hover</a></li>
								<li><a href="ui-modals.html">Modals</a></li>
								<li><a href="ui-tabs.html">Tabs</a></li>
								<li>
									<a href="ui-tooltip-popover.html">Tooltip &amp; Popover</a>
								</li>
								<li><a href="ui-sweet-alert.html">Sweet Alert</a></li>
								<li><a href="ui-notification.html">Notification</a></li>
								<li><a href="ui-timeline.html">Timeline</a></li>
								<li><a href="ui-progressbar.html">Progressbar</a></li>
								<li><a href="ui-typography.html">Typography</a></li>
								<li><a href="ui-list-group.html">List group</a></li>
								<li><a href="ui-range-slider.html">Range slider</a></li>
								<li><a href="ui-carousel.html">Carousel</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-command"></span
								><span class="mtext">Icons</span>
							</a>
							<ul class="submenu">
								<li><a href="bootstrap-icon.html">Bootstrap Icons</a></li>
								<li><a href="font-awesome.html">FontAwesome Icons</a></li>
								<li><a href="foundation.html">Foundation Icons</a></li>
								<li><a href="ionicons.html">Ionicons Icons</a></li>
								<li><a href="themify.html">Themify Icons</a></li>
								<li><a href="custom-icon.html">Custom Icons</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-pie-chart"></span
								><span class="mtext">Charts</span>
							</a>
							<ul class="submenu">
								<li><a href="highchart.html">Highchart</a></li>
								<li><a href="knob-chart.html">jQuery Knob</a></li>
								<li><a href="jvectormap.html">jvectormap</a></li>
								<li><a href="apexcharts.html">Apexcharts</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-file-earmark-text"></span
								><span class="mtext">Additional Pages</span>
							</a>
							<ul class="submenu">
								<li><a href="video-player.html">Video Player</a></li>
								<li><a href="login.html">Login</a></li>
								<li><a href="forgot-password.html">Forgot Password</a></li>
								<li><a href="reset-password.html">Reset Password</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-bug"></span
								><span class="mtext">Error Pages</span>
							</a>
							<ul class="submenu">
								<li><a href="400.html">400</a></li>
								<li><a href="403.html">403</a></li>
								<li><a href="404.html">404</a></li>
								<li><a href="500.html">500</a></li>
								<li><a href="503.html">503</a></li>
							</ul>
						</li>

						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-back"></span
								><span class="mtext">Extra Pages</span>
							</a>
							<ul class="submenu">
								<li><a href="blank.html">Blank</a></li>
								<li><a href="contact-directory.html">Contact Directory</a></li>
								<li><a href="blog.html">Blog</a></li>
								<li><a href="blog-detail.html">Blog Detail</a></li>
								<li><a href="product.html">Product</a></li>
								<li><a href="product-detail.html">Product Detail</a></li>
								<li><a href="faq.html">FAQ</a></li>
								<li><a href="profile.html">Profile</a></li>
								<li><a href="gallery.html">Gallery</a></li>
								<li><a href="pricing-table.html">Pricing Tables</a></li>
							</ul>
						</li>
						<li class="dropdown">
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-hdd-stack"></span
								><span class="mtext">Multi Level Menu</span>
							</a>
							<ul class="submenu">
								<li><a href="javascript:;">Level 1</a></li>
								<li><a href="javascript:;">Level 1</a></li>
								<li><a href="javascript:;">Level 1</a></li>
								<li class="dropdown">
									<a href="javascript:;" class="dropdown-toggle">
										<span class="micon fa fa-plug"></span
										><span class="mtext">Level 2</span>
									</a>
									<ul class="submenu child">
										<li><a href="javascript:;">Level 2</a></li>
										<li><a href="javascript:;">Level 2</a></li>
									</ul>
								</li>
								<li><a href="javascript:;">Level 1</a></li>
								<li><a href="javascript:;">Level 1</a></li>
								<li><a href="javascript:;">Level 1</a></li>
							</ul>
						</li>
						<li>
							<a href="sitemap.html" class="dropdown-toggle no-arrow">
								<span class="micon bi bi-diagram-3"></span
								><span class="mtext">Sitemap</span>
							</a>
						</li>
						<li>
							<a href="chat.html" class="dropdown-toggle no-arrow">
								<span class="micon bi bi-chat-right-dots"></span
								><span class="mtext">Chat</span>
							</a>
						</li>
						<li>
							<a href="invoice.html" class="dropdown-toggle no-arrow">
								<span class="micon bi bi-receipt-cutoff"></span
								><span class="mtext">Invoice</span>
							</a>
						</li>
						<li>
							<div class="dropdown-divider"></div>
						</li>
						<li>
							<div class="sidebar-small-cap">Extra</div>
						</li>
						<li>
							<a href="javascript:;" class="dropdown-toggle">
								<span class="micon bi bi-file-pdf"></span
								><span class="mtext">Documentation</span>
							</a>
							<ul class="submenu">
								<li><a href="introduction.html">Introduction</a></li>
								<li><a href="getting-started.html">Getting Started</a></li>
								<li><a href="color-settings.html">Color Settings</a></li>
								<li>
									<a href="third-party-plugins.html">Third Party Plugins</a>
								</li>
							</ul>
						</li>
						<li>
							<a
								href="https://dropways.github.io/deskapp-free-single-page-website-template/"
								target="_blank"
								class="dropdown-toggle no-arrow"
							>
								<span class="micon bi bi-layout-text-window-reverse"></span>
								<span class="mtext"
									>Landing Page
									<img src="vendors/images/coming-soon.png" alt="" width="25"
								/></span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="mobile-menu-overlay"></div>

		<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">
					<div class="page-header">
						<div class="row">
							<div class="col-md-6 col-sm-12">
								<div class="title">
									<h4>Custom Icons</h4>
								</div>
								<nav aria-label="breadcrumb" role="navigation">
									<ol class="breadcrumb">
										<li class="breadcrumb-item">
											<a href="index.html">Home</a>
										</li>
										<li class="breadcrumb-item active" aria-current="page">
											Icons
										</li>
									</ol>
								</nav>
							</div>
							<div class="col-md-6 col-sm-12 text-right">
								<div class="dropdown">
									<a
										class="btn btn-primary dropdown-toggle"
										href="#"
										role="button"
										data-toggle="dropdown"
									>
										January 2020
									</a>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="#">Export List</a>
										<a class="dropdown-item" href="#">Policies</a>
										<a class="dropdown-item" href="#">View Assets</a>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="search-icon-box card-box mb-30">
						<input
							type="text"
							class="border-radius-10"
							id="filter_input"
							placeholder="Search Icons..."
							title="Type in a name"
						/>
						<i class="search_icon dw dw-search"></i>
					</div>
					<div id="filter_list">
						<div class="icon-list card-box pd-20 mb-30">
							<div class="row fontawesome-icon-list custom-icon-list">
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics1"></i> dw-analytics1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-11"></i> dw-analytics-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-21"></i> dw-analytics-21
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-3"></i> dw-analytics-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-4"></i> dw-analytics-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-5"></i> dw-analytics-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-6"></i> dw-analytics-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-7"></i> dw-analytics-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-8"></i> dw-analytics-8
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-9"></i> dw-analytics-9
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-10"></i> dw-analytics-10
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-111"></i>
										dw-analytics-111
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-12"></i> dw-analytics-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-13"></i> dw-analytics-13
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-14"></i> dw-analytics-14
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-15"></i> dw-analytics-15
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-16"></i> dw-analytics-16
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-17"></i> dw-analytics-17
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-18"></i> dw-analytics-18
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-19"></i> dw-analytics-19
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-20"></i> dw-analytics-20
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-211"></i>
										dw-analytics-211
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-22"></i> dw-analytics-22
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-logout1"></i> dw-logout1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-name"></i> dw-name
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-logout-1"></i> dw-logout-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user3"></i> dw-user3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-enter"></i> dw-enter
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user-13"></i> dw-user-13
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-unlock1"></i> dw-unlock1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-logout-2"></i> dw-logout-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-password"></i> dw-password
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-lock"></i> dw-lock
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-id-card2"></i> dw-id-card2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-enter-1"></i> dw-enter-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-keyhole"></i> dw-keyhole
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user-2"></i> dw-user-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-browser2"></i> dw-browser2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-key3"></i> dw-key3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-login"></i> dw-login
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-door"></i> dw-door
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user-3"></i> dw-user-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-keyhole-1"></i> dw-keyhole-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-alarm-clock"></i> dw-alarm-clock
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-antenna"></i> dw-antenna
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-apartment"></i> dw-apartment
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shopping-bag"></i> dw-shopping-bag
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shopping-basket"></i>
										dw-shopping-basket
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shopping-basket-1"></i>
										dw-shopping-basket-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-battery"></i> dw-battery
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-battery-1"></i> dw-battery-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bell"></i> dw-bell
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-binocular"></i> dw-binocular
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sailboat"></i> dw-sailboat
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-book"></i> dw-book
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bookmark"></i> dw-bookmark
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-briefcase"></i> dw-briefcase
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-brightness"></i> dw-brightness
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-browser"></i> dw-browser
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paint-brush"></i> dw-paint-brush
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-building"></i> dw-building
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-idea"></i> dw-idea
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-school-bus"></i> dw-school-bus
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-birthday-cake"></i>
										dw-birthday-cake
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-birthday-cake-1"></i>
										dw-birthday-cake-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calculator"></i> dw-calculator
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar"></i> dw-calendar
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-1"></i> dw-calendar-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-2"></i> dw-calendar-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shopping-cart"></i>
										dw-shopping-cart
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-money"></i> dw-money
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-money-1"></i> dw-money-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-money-2"></i> dw-money-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cctv"></i> dw-cctv
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-certificate"></i> dw-certificate
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-certificate-1"></i>
										dw-certificate-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chair"></i> dw-chair
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat"></i> dw-chat
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat-1"></i> dw-chat-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chef"></i> dw-chef
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cursor"></i> dw-cursor
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wall-clock"></i> dw-wall-clock
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-coding"></i> dw-coding
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-coffee"></i> dw-coffee
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-coffee-1"></i> dw-coffee-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-compass"></i> dw-compass
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-computer"></i> dw-computer
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-computer-1"></i> dw-computer-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-agenda"></i> dw-agenda
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-crop"></i> dw-crop
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-crown"></i> dw-crown
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pendrive"></i> dw-pendrive
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-3"></i> dw-calendar-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-4"></i> dw-calendar-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ruler"></i> dw-ruler
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagram"></i> dw-diagram
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diamond"></i> dw-diamond
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-book-1"></i> dw-book-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat-2"></i> dw-chat-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat-3"></i> dw-chat-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-route"></i> dw-route
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file"></i> dw-file
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-inbox"></i> dw-inbox
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-download"></i> dw-download
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cocktail"></i> dw-cocktail
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-dumbbell"></i> dw-dumbbell
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-dvd"></i> dw-dvd
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-edit"></i> dw-edit
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-edit-1"></i> dw-edit-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-edit-2"></i> dw-edit-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mortarboard"></i> dw-mortarboard
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-5"></i> dw-calendar-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-6"></i> dw-calendar-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-factory"></i> dw-factory
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-1"></i> dw-file-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-2"></i> dw-file-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-filter"></i> dw-filter
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-filter-1"></i> dw-filter-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fire-extinguisher"></i>
										dw-fire-extinguisher
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flag"></i> dw-flag
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flame"></i> dw-flame
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flash"></i> dw-flash
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flight"></i> dw-flight
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flight-1"></i> dw-flight-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bottle"></i> dw-bottle
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-floppy-disk"></i> dw-floppy-disk
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flow"></i> dw-flow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-focus"></i> dw-focus
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder"></i> dw-folder
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-dinner"></i> dw-dinner
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fuel"></i> dw-fuel
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-gamepad"></i> dw-gamepad
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-gift"></i> dw-gift
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-trolley"></i> dw-trolley
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-package"></i> dw-package
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hammer"></i> dw-hammer
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hammer-1"></i> dw-hammer-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-headset"></i> dw-headset
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-house"></i> dw-house
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-house-1"></i> dw-house-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hook"></i> dw-hook
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-id-card"></i> dw-id-card
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-id-card-1"></i> dw-id-card-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-idea-1"></i> dw-idea-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-image"></i> dw-image
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-image-1"></i> dw-image-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-image-2"></i> dw-image-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-inbox-1"></i> dw-inbox-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-inbox-2"></i> dw-inbox-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-inbox-3"></i> dw-inbox-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-inbox-4"></i> dw-inbox-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-download-1"></i> dw-download-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bug"></i> dw-bug
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-invoice"></i> dw-invoice
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-invoice-1"></i> dw-invoice-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-key"></i> dw-key
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-startup"></i> dw-startup
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-startup-1"></i> dw-startup-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-library"></i> dw-library
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-idea-2"></i> dw-idea-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-lighthouse"></i> dw-lighthouse
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-link"></i> dw-link
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin"></i> dw-pin
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-1"></i> dw-pin-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-padlock"></i> dw-padlock
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-magic-wand"></i> dw-magic-wand
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-magnifying-glass"></i>
										dw-magnifying-glass
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-email"></i> dw-email
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-email-1"></i> dw-email-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map"></i> dw-map
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-2"></i> dw-pin-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-1"></i> dw-map-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-marker"></i> dw-marker
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-first-aid-kit"></i>
										dw-first-aid-kit
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mail"></i> dw-mail
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat-4"></i> dw-chat-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-email-2"></i> dw-email-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chip"></i> dw-chip
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chip-1"></i> dw-chip-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-microphone"></i> dw-microphone
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-microphone-1"></i> dw-microphone-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-smartphone"></i> dw-smartphone
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cocktail-1"></i> dw-cocktail-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-more"></i> dw-more
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ticket"></i> dw-ticket
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-compass-1"></i> dw-compass-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-add-file"></i> dw-add-file
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-nib"></i> dw-nib
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-notebook"></i> dw-notebook
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-notepad"></i> dw-notepad
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-notepad-1"></i> dw-notepad-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-notepad-2"></i> dw-notepad-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-notification"></i> dw-notification
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-notification-1"></i>
										dw-notification-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-open-book"></i> dw-open-book
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-open-book-1"></i> dw-open-book-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-3"></i> dw-file-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paint-bucket"></i> dw-paint-bucket
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paint-roller"></i> dw-paint-roller
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paper-plane"></i> dw-paper-plane
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pen"></i> dw-pen
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pencil"></i> dw-pencil
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pencil-1"></i> dw-pencil-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-smartphone-1"></i> dw-smartphone-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-photo-camera"></i> dw-photo-camera
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-push-pin"></i> dw-push-pin
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-3"></i> dw-pin-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-push-pin-1"></i> dw-push-pin-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-push-pin-2"></i> dw-push-pin-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-player"></i> dw-video-player
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-swimming-pool"></i>
										dw-swimming-pool
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-presentation"></i> dw-presentation
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-presentation-1"></i>
										dw-presentation-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-presentation-2"></i>
										dw-presentation-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-4"></i> dw-file-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user"></i> dw-user
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-property"></i> dw-property
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wallet"></i> dw-wallet
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-radio"></i> dw-radio
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-radio-1"></i> dw-radio-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-random"></i> dw-random
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-open-book-2"></i> dw-open-book-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-reload"></i> dw-reload
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cutlery"></i> dw-cutlery
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-startup-2"></i> dw-startup-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-router"></i> dw-router
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ruler-1"></i> dw-ruler-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-safebox"></i> dw-safebox
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hourglass"></i> dw-hourglass
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-satellite"></i> dw-satellite
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-7"></i> dw-calendar-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-monitor"></i> dw-monitor
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-monitor-1"></i> dw-monitor-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-search"></i> dw-search
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cursor-1"></i> dw-cursor-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-settings"></i> dw-settings
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-share"></i> dw-share
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-share-1"></i> dw-share-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-share-2"></i> dw-share-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-crane"></i> dw-crane
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ship"></i> dw-ship
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shopping-cart-1"></i>
										dw-shopping-cart-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sim-card"></i> dw-sim-card
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sofa"></i> dw-sofa
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-speaker"></i> dw-speaker
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-speaker-1"></i> dw-speaker-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-speech"></i> dw-speech
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-stamp"></i> dw-stamp
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-stethoscope"></i> dw-stethoscope
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-suitcase"></i> dw-suitcase
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-syringe"></i> dw-syringe
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tag"></i> dw-tag
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tag-1"></i> dw-tag-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-target"></i> dw-target
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tea"></i> dw-tea
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chip-2"></i> dw-chip-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-telescope"></i> dw-telescope
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ticket-1"></i> dw-ticket-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ticket-2"></i> dw-ticket-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-8"></i> dw-calendar-8
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-torch"></i> dw-torch
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-train"></i> dw-train
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-delivery-truck"></i>
										dw-delivery-truck
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-delivery-truck-1"></i>
										dw-delivery-truck-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-delivery-truck-2"></i>
										dw-delivery-truck-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-trash"></i> dw-trash
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-suitcase-1"></i> dw-suitcase-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-television"></i> dw-television
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-umbrella"></i> dw-umbrella
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-outbox"></i> dw-outbox
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-upload"></i> dw-upload
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-usb"></i> dw-usb
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user-1"></i> dw-user-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-camera"></i> dw-video-camera
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-gallery"></i> dw-gallery
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-film-reel"></i> dw-film-reel
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-player-1"></i>
										dw-video-player-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wallet-1"></i> dw-wallet-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-watch"></i> dw-watch
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bottle-1"></i> dw-bottle-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-coding-1"></i> dw-coding-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wifi"></i> dw-wifi
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-writing"></i> dw-writing
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-zoom-in"></i> dw-zoom-in
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-zoom-out"></i> dw-zoom-out
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow"></i> dw-down-arrow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow"></i> dw-up-arrow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow"></i> dw-left-arrow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-1"></i> dw-up-arrow-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shrink"></i> dw-shrink
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-skip"></i> dw-skip
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-minimize"></i> dw-minimize
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-back"></i> dw-back
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow"></i>
										dw-diagonal-arrow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-2"></i> dw-up-arrow-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-1"></i>
										dw-diagonal-arrow-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-1"></i> dw-down-arrow-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-3"></i> dw-up-arrow-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-return"></i> dw-return
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-share1"></i> dw-share1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow-1"></i> dw-left-arrow-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-2"></i>
										dw-diagonal-arrow-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-return-1"></i> dw-return-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-3"></i>
										dw-diagonal-arrow-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-curved-arrow"></i> dw-curved-arrow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-resize"></i> dw-resize
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-minimize-1"></i> dw-minimize-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-resize-1"></i> dw-resize-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-4"></i> dw-up-arrow-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-2"></i> dw-down-arrow-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-return-2"></i> dw-return-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-return-3"></i> dw-return-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-return-4"></i> dw-return-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-resize-2"></i> dw-resize-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-4"></i>
										dw-diagonal-arrow-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-5"></i>
										dw-diagonal-arrow-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-resize-3"></i> dw-resize-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-3"></i> dw-down-arrow-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shrink-1"></i> dw-shrink-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-6"></i>
										dw-diagonal-arrow-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-7"></i>
										dw-diagonal-arrow-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-8"></i>
										dw-diagonal-arrow-8
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-minimize-2"></i> dw-minimize-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-minimize-3"></i> dw-minimize-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-9"></i>
										dw-diagonal-arrow-9
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-10"></i>
										dw-diagonal-arrow-10
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-11"></i>
										dw-diagonal-arrow-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-12"></i>
										dw-diagonal-arrow-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-13"></i>
										dw-diagonal-arrow-13
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-14"></i>
										dw-diagonal-arrow-14
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-15"></i>
										dw-diagonal-arrow-15
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-16"></i>
										dw-diagonal-arrow-16
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shrink-2"></i> dw-shrink-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-17"></i>
										dw-diagonal-arrow-17
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-5"></i> dw-up-arrow-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow1"></i> dw-left-arrow1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow"></i> dw-right-arrow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow-1"></i>
										dw-right-arrow-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-expand"></i> dw-expand
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sort"></i> dw-sort
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-switch"></i> dw-switch
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-expand-1"></i> dw-expand-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow-2"></i>
										dw-right-arrow-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shuffle"></i> dw-shuffle
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow-11"></i>
										dw-left-arrow-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow1"></i> dw-down-arrow1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-11"></i>
										dw-down-arrow-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow1"></i>
										dw-diagonal-arrow1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-18"></i>
										dw-diagonal-arrow-18
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow-2"></i> dw-left-arrow-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow-3"></i> dw-left-arrow-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rotate"></i> dw-rotate
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-21"></i>
										dw-down-arrow-21
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow-3"></i>
										dw-right-arrow-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-21"></i>
										dw-diagonal-arrow-21
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-repeat"></i> dw-repeat
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow-4"></i>
										dw-right-arrow-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-31"></i>
										dw-down-arrow-31
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow1"></i> dw-up-arrow1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-11"></i> dw-up-arrow-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow-5"></i>
										dw-right-arrow-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow-4"></i> dw-left-arrow-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-21"></i> dw-up-arrow-21
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow-5"></i> dw-left-arrow-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-4"></i> dw-down-arrow-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-31"></i> dw-up-arrow-31
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-31"></i>
										dw-diagonal-arrow-31
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow-6"></i>
										dw-right-arrow-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-move"></i> dw-move
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-refresh"></i> dw-refresh
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-41"></i>
										dw-diagonal-arrow-41
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-5"></i> dw-down-arrow-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-repeat-1"></i> dw-repeat-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow-41"></i> dw-up-arrow-41
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow-7"></i>
										dw-right-arrow-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow-8"></i>
										dw-right-arrow-8
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-51"></i>
										dw-diagonal-arrow-51
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow-6"></i> dw-left-arrow-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-6"></i> dw-down-arrow-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow-7"></i> dw-down-arrow-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-61"></i>
										dw-diagonal-arrow-61
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-return1"></i> dw-return1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-71"></i>
										dw-diagonal-arrow-71
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-81"></i>
										dw-diagonal-arrow-81
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-91"></i>
										dw-diagonal-arrow-91
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-align"></i> dw-down-align
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-align1"></i> dw-down-align1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-align2"></i> dw-down-align2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-center-align"></i> dw-center-align
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-center-align1"></i>
										dw-center-align1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-center-align2"></i>
										dw-center-align2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-center-align3"></i>
										dw-center-align3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-left"></i> dw-align-left
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-left1"></i> dw-align-left1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-left2"></i> dw-align-left2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-right"></i> dw-align-right
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-right1"></i> dw-align-right1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-right2"></i> dw-align-right2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-align"></i> dw-up-align
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-align1"></i> dw-up-align1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-align2"></i> dw-up-align2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bottom"></i> dw-bottom
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bottom1"></i> dw-bottom1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-align3"></i> dw-down-align3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-center-align4"></i>
										dw-center-align4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-center-align5"></i>
										dw-center-align5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-center-align6"></i>
										dw-center-align6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-grid"></i> dw-grid
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rows"></i> dw-rows
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-header"></i> dw-header
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-inner"></i> dw-inner
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-layout"></i> dw-layout
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-layout1"></i> dw-layout1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-layout2"></i> dw-layout2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-panel"></i> dw-panel
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-panel1"></i> dw-panel1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sidebar"></i> dw-sidebar
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-align"></i> dw-left-align
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-no-border"></i> dw-no-border
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-outer"></i> dw-outer
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-header1"></i> dw-header1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-panel2"></i> dw-panel2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-panel3"></i> dw-panel3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sidebar1"></i> dw-sidebar1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-align"></i> dw-right-align
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-grid1"></i> dw-grid1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-table"></i> dw-table
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-columns"></i> dw-columns
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-columns1"></i> dw-columns1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-panel4"></i> dw-panel4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-panel5"></i> dw-panel5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-columns2"></i> dw-columns2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rows1"></i> dw-rows1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rows2"></i> dw-rows2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-align3"></i> dw-up-align3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat1"></i> dw-chat1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-center"></i> dw-align-center
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-left3"></i> dw-align-left3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-align-right3"></i> dw-align-right3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bold"></i> dw-bold
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-broken-link"></i> dw-broken-link
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-clear-format"></i> dw-clear-format
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-clipboard"></i> dw-clipboard
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-columns3"></i> dw-columns3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file1"></i> dw-file1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-scissors"></i> dw-scissors
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-size"></i> dw-size
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat2"></i> dw-chat2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-edit1"></i> dw-edit1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-font"></i> dw-font
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-grammar"></i> dw-grammar
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-highlight"></i> dw-highlight
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-idea1"></i> dw-idea1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-font1"></i> dw-font1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-italic"></i> dw-italic
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-indent"></i> dw-left-indent
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-line-spacing"></i> dw-line-spacing
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-link1"></i> dw-link1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-link2"></i> dw-link2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-list"></i> dw-list
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-more1"></i> dw-more1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-note"></i> dw-note
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-note1"></i> dw-note1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-note2"></i> dw-note2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-list1"></i> dw-list1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-list2"></i> dw-list2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-page"></i> dw-page
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-page1"></i> dw-page1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paperclip"></i> dw-paperclip
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paragraph"></i> dw-paragraph
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paragraph1"></i> dw-paragraph1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paste"></i> dw-paste
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-note3"></i> dw-note3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-print"></i> dw-print
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-redo"></i> dw-redo
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-indent"></i> dw-right-indent
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diskette"></i> dw-diskette
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-search1"></i> dw-search1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-size1"></i> dw-size1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin1"></i> dw-pin1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-table1"></i> dw-table1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-text"></i> dw-text
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-text1"></i> dw-text1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-underline"></i> dw-underline
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-undo"></i> dw-undo
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow2"></i> dw-down-arrow2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-arrow2"></i> dw-up-arrow2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-arrow2"></i> dw-left-arrow2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-arrow1"></i> dw-right-arrow1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow2"></i>
										dw-diagonal-arrow2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-19"></i>
										dw-diagonal-arrow-19
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-22"></i>
										dw-diagonal-arrow-22
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diagonal-arrow-32"></i>
										dw-diagonal-arrow-32
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-double-arrow"></i> dw-double-arrow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-double-arrow-1"></i>
										dw-double-arrow-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bus"></i> dw-bus
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-truck"></i> dw-truck
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ambulance"></i> dw-ambulance
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-helicopters"></i> dw-helicopters
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sailboat1"></i> dw-sailboat1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cable-car-cabin"></i>
										dw-cable-car-cabin
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shop"></i> dw-shop
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-groceries-store"></i>
										dw-groceries-store
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pagoda"></i> dw-pagoda
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-coffee-cup"></i> dw-coffee-cup
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sort1"></i> dw-sort1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-food-cart"></i> dw-food-cart
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mosque"></i> dw-mosque
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-building1"></i> dw-building1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-police-box"></i> dw-police-box
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-caravan"></i> dw-caravan
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-school"></i> dw-school
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-kayak"></i> dw-kayak
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-skyscraper"></i> dw-skyscraper
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-building-1"></i> dw-building-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bonfire"></i> dw-bonfire
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-exchange"></i> dw-exchange
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tent"></i> dw-tent
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-house1"></i> dw-house1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hospital"></i> dw-hospital
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-factory1"></i> dw-factory1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-city-hall"></i> dw-city-hall
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-city"></i> dw-city
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bridge"></i> dw-bridge
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ferris-wheel"></i> dw-ferris-wheel
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-billboard"></i> dw-billboard
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-phone-booth"></i> dw-phone-booth
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-expand1"></i> dw-expand1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bus-stop"></i> dw-bus-stop
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-turn-right"></i> dw-turn-right
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-street-light"></i> dw-street-light
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hotel"></i> dw-hotel
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-obelisk"></i> dw-obelisk
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-electric-tower"></i>
										dw-electric-tower
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-signboard"></i> dw-signboard
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-traffic-light"></i>
										dw-traffic-light
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hydrant"></i> dw-hydrant
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bench"></i> dw-bench
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-move1"></i> dw-move1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fountain"></i> dw-fountain
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-panels"></i> dw-panels
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mountain"></i> dw-mountain
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-barn"></i> dw-barn
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-desert"></i> dw-desert
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-trees"></i> dw-trees
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-house-11"></i> dw-house-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sun-umbrella"></i> dw-sun-umbrella
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-island"></i> dw-island
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-waterfall"></i> dw-waterfall
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-expand-11"></i> dw-expand-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-windmill"></i> dw-windmill
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-helm"></i> dw-helm
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-anchor"></i> dw-anchor
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-umbrella1"></i> dw-umbrella1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-polaroids"></i> dw-polaroids
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-lifesaver"></i> dw-lifesaver
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-suitcase1"></i> dw-suitcase1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-earth-globe"></i> dw-earth-globe
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flight1"></i> dw-flight1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-heart"></i> dw-heart
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-compress"></i> dw-compress
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-download1"></i> dw-download1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-upload1"></i> dw-upload1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-search2"></i> dw-search2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-image1"></i> dw-image1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-trash1"></i> dw-trash1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-attachment"></i> dw-attachment
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-edit2"></i> dw-edit2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-email1"></i> dw-email1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shopping-cart1"></i>
										dw-shopping-cart1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user1"></i> dw-user1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-curve-arrow"></i> dw-curve-arrow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-add-user"></i> dw-add-user
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cloud"></i> dw-cloud
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bug1"></i> dw-bug1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fire"></i> dw-fire
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-copyright"></i> dw-copyright
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-star"></i> dw-star
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-star-1"></i> dw-star-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-notification1"></i>
										dw-notification1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-notification-11"></i>
										dw-notification-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-volume"></i> dw-volume
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-curve-arrow-1"></i>
										dw-curve-arrow-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-list3"></i> dw-list3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-check"></i> dw-check
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-expand-2"></i> dw-expand-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-subtitles"></i> dw-subtitles
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paper-plane1"></i> dw-paper-plane1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-zoom-in1"></i> dw-zoom-in1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-zoom-out1"></i> dw-zoom-out1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-settings1"></i> dw-settings1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file2"></i> dw-file2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-11"></i> dw-file-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-curved-arrow1"></i>
										dw-curved-arrow1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-add-file1"></i> dw-add-file1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-21"></i> dw-file-21
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-31"></i> dw-file-31
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-edit-file"></i> dw-edit-file
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-audio-file"></i> dw-audio-file
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-image-11"></i> dw-image-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-file"></i> dw-video-file
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-41"></i> dw-file-41
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-camera1"></i>
										dw-video-camera1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-camera-1"></i>
										dw-video-camera-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-curve-arrow-2"></i>
										dw-curve-arrow-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-phone-call"></i> dw-phone-call
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-phone-call-1"></i> dw-phone-call-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-photo-camera1"></i>
										dw-photo-camera1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wall-clock1"></i> dw-wall-clock1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-refresh1"></i> dw-refresh1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-padlock1"></i> dw-padlock1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-open-padlock"></i> dw-open-padlock
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-price-tag"></i> dw-price-tag
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-inbox1"></i> dw-inbox1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-outbox1"></i> dw-outbox1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-chevron"></i> dw-down-chevron
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cancel"></i> dw-cancel
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-warning"></i> dw-warning
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-question"></i> dw-question
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat3"></i> dw-chat3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar1"></i> dw-calendar1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder1"></i> dw-folder1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-like"></i> dw-like
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-thumb-down"></i> dw-thumb-down
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-filter1"></i> dw-filter1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-worldwide"></i> dw-worldwide
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-chevron"></i> dw-up-chevron
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-smartphone1"></i> dw-smartphone1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tablet"></i> dw-tablet
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-personal-computer"></i>
										dw-personal-computer
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diskette1"></i> dw-diskette1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-logout"></i> dw-logout
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-menu"></i> dw-menu
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-menu-1"></i> dw-menu-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-menu-2"></i> dw-menu-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-credit-card"></i> dw-credit-card
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-eye"></i> dw-eye
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-chevron"></i> dw-left-chevron
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hide"></i> dw-hide
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-crown1"></i> dw-crown1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paint-palette"></i>
										dw-paint-palette
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-undo1"></i> dw-undo1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-redo1"></i> dw-redo1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-opacity"></i> dw-opacity
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-copy"></i> dw-copy
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-layers"></i> dw-layers
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sheet"></i> dw-sheet
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shield"></i> dw-shield
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-chevron"></i>
										dw-right-chevron
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-quotation"></i> dw-quotation
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cookie"></i> dw-cookie
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-link3"></i> dw-link3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-book1"></i> dw-book1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-coupon"></i> dw-coupon
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cursor1"></i> dw-cursor1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cursor-11"></i> dw-cursor-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-suitcase-11"></i> dw-suitcase-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-group"></i> dw-group
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-conference"></i> dw-conference
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-chevron-1"></i>
										dw-down-chevron-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-deal"></i> dw-deal
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-id-card1"></i> dw-id-card1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-human-resources"></i>
										dw-human-resources
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-goal"></i> dw-goal
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-meeting"></i> dw-meeting
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-elderly"></i> dw-elderly
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-insurance"></i> dw-insurance
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user-11"></i> dw-user-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-time-management"></i>
										dw-time-management
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-strategy"></i> dw-strategy
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-up-chevron-1"></i> dw-up-chevron-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-workflow"></i> dw-workflow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pyramid-chart"></i>
										dw-pyramid-chart
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-profits"></i> dw-profits
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-loss"></i> dw-loss
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bar-chart"></i> dw-bar-chart
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-profits-1"></i> dw-profits-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-loss-1"></i> dw-loss-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pie-chart"></i> dw-pie-chart
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bar-chart-1"></i> dw-bar-chart-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-agenda1"></i> dw-agenda1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-left-chevron-1"></i>
										dw-left-chevron-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flower"></i> dw-flower
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pamela"></i> dw-pamela
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-branch"></i> dw-branch
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-winter"></i> dw-winter
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rainy"></i> dw-rainy
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rainy-1"></i> dw-rainy-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rainy-2"></i> dw-rainy-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-umbrella-1"></i> dw-umbrella-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cloud-1"></i> dw-cloud-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-clouds"></i> dw-clouds
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-right-chevron-1"></i>
										dw-right-chevron-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cloudy-night"></i> dw-cloudy-night
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sun"></i> dw-sun
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-thermometer"></i> dw-thermometer
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-thermometer-1"></i>
										dw-thermometer-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-thermometer-2"></i>
										dw-thermometer-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-thermometer-3"></i>
										dw-thermometer-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-thermometer-4"></i>
										dw-thermometer-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-drop"></i> dw-drop
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-windy"></i> dw-windy
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wind"></i> dw-wind
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shuffle1"></i> dw-shuffle1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wind-1"></i> dw-wind-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wind-2"></i> dw-wind-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-snow"></i> dw-snow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-snowflake"></i> dw-snowflake
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-snowflake-1"></i> dw-snowflake-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-windy-1"></i> dw-windy-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hail"></i> dw-hail
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rainbow"></i> dw-rainbow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rainbow-1"></i> dw-rainbow-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rainbow-2"></i> dw-rainbow-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-recycle"></i> dw-recycle
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rainbow-3"></i> dw-rainbow-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-storm"></i> dw-storm
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bolt"></i> dw-bolt
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cloudy"></i> dw-cloudy
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cloudy-1"></i> dw-cloudy-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cloudy-2"></i> dw-cloudy-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-eclipse"></i> dw-eclipse
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-moon-phase"></i> dw-moon-phase
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-moon-phase-1"></i> dw-moon-phase-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-moon-phase-2"></i> dw-moon-phase-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-split"></i> dw-split
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-moon-phase-3"></i> dw-moon-phase-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-moon-phase-4"></i> dw-moon-phase-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-moon-phase-5"></i> dw-moon-phase-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-half-moon"></i> dw-half-moon
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hurricane"></i> dw-hurricane
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-foggy"></i> dw-foggy
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-co2"></i> dw-co2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-humidity"></i> dw-humidity
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tornado"></i> dw-tornado
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-basketball"></i> dw-basketball
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-merge"></i> dw-merge
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-baseball"></i> dw-baseball
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-football"></i> dw-football
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-volleyball"></i> dw-volleyball
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rugby-ball"></i> dw-rugby-ball
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tennis"></i> dw-tennis
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bowling"></i> dw-bowling
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ice-skate"></i> dw-ice-skate
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-roller-skate"></i> dw-roller-skate
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-skateboard"></i> dw-skateboard
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-karate"></i> dw-karate
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-u-turn"></i> dw-u-turn
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ice-hockey"></i> dw-ice-hockey
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-golf"></i> dw-golf
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-boxing"></i> dw-boxing
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-surfboard"></i> dw-surfboard
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-dart"></i> dw-dart
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-goal-1"></i> dw-goal-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-badminton"></i> dw-badminton
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ping-pong"></i> dw-ping-pong
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-racket"></i> dw-racket
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-soccer-field"></i> dw-soccer-field
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-split-1"></i> dw-split-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-basketball-court"></i>
										dw-basketball-court
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tennis-court"></i> dw-tennis-court
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-american-football"></i>
										dw-american-football
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mountain-1"></i> dw-mountain-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mountain-2"></i> dw-mountain-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mountain-3"></i> dw-mountain-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-night"></i> dw-night
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rainbow-4"></i> dw-rainbow-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-barn-1"></i> dw-barn-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-trees-1"></i> dw-trees-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-split-2"></i> dw-split-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-desert-1"></i> dw-desert-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-road"></i> dw-road
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sunrise"></i> dw-sunrise
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sunset"></i> dw-sunset
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-beach-house"></i> dw-beach-house
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sunbed"></i> dw-sunbed
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-island-1"></i> dw-island-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sailboat-1"></i> dw-sailboat-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-waterfall-1"></i> dw-waterfall-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-windmill-1"></i> dw-windmill-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-triple-arrows"></i>
										dw-triple-arrows
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-plant"></i> dw-plant
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flower-1"></i> dw-flower-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sprout"></i> dw-sprout
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-plant-1"></i> dw-plant-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wheat"></i> dw-wheat
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-harvest"></i> dw-harvest
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rose"></i> dw-rose
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-poppy"></i> dw-poppy
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tulip"></i> dw-tulip
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pinwheel"></i> dw-pinwheel
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-happy"></i> dw-happy
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fruit-tree"></i> dw-fruit-tree
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tree"></i> dw-tree
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pine"></i> dw-pine
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pine-1"></i> dw-pine-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-palm-tree"></i> dw-palm-tree
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cactus"></i> dw-cactus
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-recycle-1"></i> dw-recycle-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sprout-1"></i> dw-sprout-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-save-water"></i> dw-save-water
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-faucet"></i> dw-faucet
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sad"></i> dw-sad
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ecology"></i> dw-ecology
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cat"></i> dw-cat
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-dog"></i> dw-dog
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-horse"></i> dw-horse
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bird"></i> dw-bird
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rabbit"></i> dw-rabbit
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-butterfly"></i> dw-butterfly
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-deer"></i> dw-deer
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sheep"></i> dw-sheep
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-monkey"></i> dw-monkey
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-meh"></i> dw-meh
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-burger"></i> dw-burger
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pizza"></i> dw-pizza
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sandwich"></i> dw-sandwich
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hot-dog"></i> dw-hot-dog
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chicken-leg"></i> dw-chicken-leg
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-french-fries"></i> dw-french-fries
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tomato"></i> dw-tomato
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-onion"></i> dw-onion
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bell-pepper"></i> dw-bell-pepper
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cabbage"></i> dw-cabbage
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-support"></i> dw-support
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-corn"></i> dw-corn
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pumpkin"></i> dw-pumpkin
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-eggplant"></i> dw-eggplant
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-carrot"></i> dw-carrot
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-broccoli"></i> dw-broccoli
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-avocado"></i> dw-avocado
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pear"></i> dw-pear
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-strawberry"></i> dw-strawberry
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pineapple"></i> dw-pineapple
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-orange"></i> dw-orange
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-support-1"></i> dw-support-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-banana"></i> dw-banana
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-watermelon"></i> dw-watermelon
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-grapes"></i> dw-grapes
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cherry"></i> dw-cherry
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bread"></i> dw-bread
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-steak"></i> dw-steak
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cheese"></i> dw-cheese
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fried-egg"></i> dw-fried-egg
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-soup"></i> dw-soup
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-salad"></i> dw-salad
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-information"></i> dw-information
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fish"></i> dw-fish
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shrimp"></i> dw-shrimp
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-crab"></i> dw-crab
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cake"></i> dw-cake
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-muffin"></i> dw-muffin
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pancakes"></i> dw-pancakes
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-water"></i> dw-water
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-milk"></i> dw-milk
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-soda"></i> dw-soda
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wine"></i> dw-wine
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-question-1"></i> dw-question-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-energy-drink"></i> dw-energy-drink
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tea-cup"></i> dw-tea-cup
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-coffee-cup-1"></i> dw-coffee-cup-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-beer"></i> dw-beer
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-warning-1"></i> dw-warning-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat-11"></i> dw-chat-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar-11"></i> dw-calendar-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-help"></i> dw-help
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cone"></i> dw-cone
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-counterclockwise"></i>
										dw-counterclockwise
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-headphones"></i> dw-headphones
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-key1"></i> dw-key1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-server"></i> dw-server
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-24-hours"></i> dw-24-hours
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-target1"></i> dw-target1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-target-1"></i> dw-target-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-target-2"></i> dw-target-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin2"></i> dw-pin2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-11"></i> dw-pin-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-21"></i> dw-pin-21
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-31"></i> dw-pin-31
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-4"></i> dw-pin-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-5"></i> dw-pin-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flag1"></i> dw-flag1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-6"></i> dw-pin-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-7"></i> dw-pin-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-finger"></i> dw-finger
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-position"></i> dw-position
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-position-1"></i> dw-position-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-compass1"></i> dw-compass1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wind-rose"></i> dw-wind-rose
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cursor-2"></i> dw-cursor-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-route1"></i> dw-route1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-distance"></i> dw-distance
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pin-8"></i> dw-pin-8
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-worldwide-1"></i> dw-worldwide-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-internet"></i> dw-internet
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-internet-1"></i> dw-internet-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-internet-2"></i> dw-internet-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map1"></i> dw-map1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-11"></i> dw-map-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-2"></i> dw-map-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-3"></i> dw-map-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-4"></i> dw-map-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-5"></i> dw-map-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-6"></i> dw-map-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-7"></i> dw-map-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-panel6"></i> dw-panel6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bookmark1"></i> dw-bookmark1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wifi1"></i> dw-wifi1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-car"></i> dw-car
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-taxi"></i> dw-taxi
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flight-11"></i> dw-flight-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-boat"></i> dw-boat
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-rocket"></i> dw-rocket
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-metro"></i> dw-metro
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-train1"></i> dw-train1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tram"></i> dw-tram
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-motorcycle"></i> dw-motorcycle
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bicycle"></i> dw-bicycle
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-add-file2"></i> dw-add-file2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-add-file-1"></i> dw-add-file-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder2"></i> dw-folder2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-1"></i> dw-folder-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-2"></i> dw-folder-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-add-file-2"></i> dw-add-file-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file3"></i> dw-file3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-12"></i> dw-file-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-3"></i> dw-folder-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-4"></i> dw-folder-4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-5"></i> dw-folder-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-22"></i> dw-file-22
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-32"></i> dw-file-32
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-42"></i> dw-file-42
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-6"></i> dw-folder-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-7"></i> dw-folder-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-8"></i> dw-folder-8
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-5"></i> dw-file-5
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-6"></i> dw-file-6
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-7"></i> dw-file-7
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-9"></i> dw-folder-9
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-10"></i> dw-folder-10
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-11"></i> dw-folder-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-8"></i> dw-file-8
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-9"></i> dw-file-9
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-10"></i> dw-file-10
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-12"></i> dw-folder-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-13"></i> dw-folder-13
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-14"></i> dw-folder-14
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-111"></i> dw-file-111
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics"></i> dw-analytics
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-1"></i> dw-analytics-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-15"></i> dw-folder-15
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-16"></i> dw-folder-16
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-17"></i> dw-folder-17
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-analytics-2"></i> dw-analytics-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-121"></i> dw-file-121
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-13"></i> dw-file-13
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-18"></i> dw-folder-18
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-19"></i> dw-folder-19
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-20"></i> dw-folder-20
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-14"></i> dw-file-14
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-15"></i> dw-file-15
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-16"></i> dw-file-16
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-21"></i> dw-folder-21
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-22"></i> dw-folder-22
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-23"></i> dw-folder-23
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-17"></i> dw-file-17
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-18"></i> dw-file-18
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-19"></i> dw-file-19
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-24"></i> dw-folder-24
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-25"></i> dw-folder-25
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-26"></i> dw-folder-26
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-20"></i> dw-file-20
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-211"></i> dw-file-211
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-221"></i> dw-file-221
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-27"></i> dw-folder-27
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-28"></i> dw-folder-28
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-29"></i> dw-folder-29
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-23"></i> dw-file-23
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-24"></i> dw-file-24
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-25"></i> dw-file-25
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-30"></i> dw-folder-30
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-31"></i> dw-folder-31
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-32"></i> dw-folder-32
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-26"></i> dw-file-26
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-27"></i> dw-file-27
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-28"></i> dw-file-28
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-33"></i> dw-folder-33
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-34"></i> dw-folder-34
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-35"></i> dw-folder-35
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-29"></i> dw-file-29
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-30"></i> dw-file-30
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-311"></i> dw-file-311
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-36"></i> dw-folder-36
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-37"></i> dw-folder-37
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-38"></i> dw-folder-38
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-321"></i> dw-file-321
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-33"></i> dw-file-33
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-34"></i> dw-file-34
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-39"></i> dw-folder-39
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-40"></i> dw-folder-40
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-41"></i> dw-folder-41
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-35"></i> dw-file-35
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-36"></i> dw-file-36
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-37"></i> dw-file-37
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-42"></i> dw-folder-42
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-43"></i> dw-folder-43
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-44"></i> dw-folder-44
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-38"></i> dw-file-38
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-39"></i> dw-file-39
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-40"></i> dw-file-40
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-45"></i> dw-folder-45
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-46"></i> dw-folder-46
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-47"></i> dw-folder-47
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-411"></i> dw-file-411
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-421"></i> dw-file-421
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-43"></i> dw-file-43
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-48"></i> dw-folder-48
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-49"></i> dw-folder-49
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-50"></i> dw-folder-50
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-44"></i> dw-file-44
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-45"></i> dw-file-45
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-46"></i> dw-file-46
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-51"></i> dw-folder-51
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-52"></i> dw-folder-52
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-53"></i> dw-folder-53
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-47"></i> dw-file-47
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-48"></i> dw-file-48
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-49"></i> dw-file-49
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-54"></i> dw-folder-54
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-55"></i> dw-folder-55
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-56"></i> dw-folder-56
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-50"></i> dw-file-50
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-51"></i> dw-file-51
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-52"></i> dw-file-52
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-57"></i> dw-folder-57
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-58"></i> dw-folder-58
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-59"></i> dw-folder-59
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-53"></i> dw-file-53
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-60"></i> dw-folder-60
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-54"></i> dw-file-54
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-55"></i> dw-file-55
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-61"></i> dw-folder-61
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-62"></i> dw-folder-62
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-63"></i> dw-folder-63
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-56"></i> dw-file-56
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-57"></i> dw-file-57
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-58"></i> dw-file-58
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-64"></i> dw-folder-64
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-65"></i> dw-folder-65
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-66"></i> dw-folder-66
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-59"></i> dw-file-59
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-60"></i> dw-file-60
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-61"></i> dw-file-61
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-67"></i> dw-folder-67
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-68"></i> dw-folder-68
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-69"></i> dw-folder-69
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-62"></i> dw-file-62
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-63"></i> dw-file-63
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-64"></i> dw-file-64
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-70"></i> dw-folder-70
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-71"></i> dw-folder-71
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-72"></i> dw-folder-72
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-65"></i> dw-file-65
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-66"></i> dw-file-66
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-67"></i> dw-file-67
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-73"></i> dw-folder-73
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-74"></i> dw-folder-74
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-75"></i> dw-folder-75
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-68"></i> dw-file-68
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-69"></i> dw-file-69
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-70"></i> dw-file-70
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-76"></i> dw-folder-76
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-77"></i> dw-folder-77
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-78"></i> dw-folder-78
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-71"></i> dw-file-71
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-72"></i> dw-file-72
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-73"></i> dw-file-73
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-79"></i> dw-folder-79
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-80"></i> dw-folder-80
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-81"></i> dw-folder-81
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-74"></i> dw-file-74
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-75"></i> dw-file-75
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-76"></i> dw-file-76
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-82"></i> dw-folder-82
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-83"></i> dw-folder-83
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-77"></i> dw-file-77
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-78"></i> dw-file-78
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-79"></i> dw-file-79
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-84"></i> dw-folder-84
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-85"></i> dw-folder-85
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-86"></i> dw-folder-86
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-80"></i> dw-file-80
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-81"></i> dw-file-81
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-82"></i> dw-file-82
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-87"></i> dw-folder-87
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-88"></i> dw-folder-88
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-89"></i> dw-folder-89
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-83"></i> dw-file-83
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-84"></i> dw-file-84
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-85"></i> dw-file-85
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-90"></i> dw-folder-90
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-91"></i> dw-folder-91
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-92"></i> dw-folder-92
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-86"></i> dw-file-86
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-87"></i> dw-file-87
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-88"></i> dw-file-88
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-93"></i> dw-folder-93
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-94"></i> dw-folder-94
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-95"></i> dw-folder-95
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-89"></i> dw-file-89
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-90"></i> dw-file-90
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-91"></i> dw-file-91
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-96"></i> dw-folder-96
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-97"></i> dw-folder-97
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-98"></i> dw-folder-98
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-92"></i> dw-file-92
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-93"></i> dw-file-93
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-94"></i> dw-file-94
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-99"></i> dw-folder-99
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-100"></i> dw-folder-100
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-101"></i> dw-folder-101
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-95"></i> dw-file-95
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-96"></i> dw-file-96
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-97"></i> dw-file-97
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-102"></i> dw-folder-102
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-103"></i> dw-folder-103
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-104"></i> dw-folder-104
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-98"></i> dw-file-98
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-99"></i> dw-file-99
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-100"></i> dw-file-100
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-105"></i> dw-folder-105
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-106"></i> dw-folder-106
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-107"></i> dw-folder-107
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-101"></i> dw-file-101
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-102"></i> dw-file-102
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-103"></i> dw-file-103
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-108"></i> dw-folder-108
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-109"></i> dw-folder-109
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-110"></i> dw-folder-110
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-104"></i> dw-file-104
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-remove"></i> dw-remove
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-remove-1"></i> dw-remove-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-111"></i> dw-folder-111
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-112"></i> dw-folder-112
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-113"></i> dw-folder-113
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-105"></i> dw-file-105
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-106"></i> dw-file-106
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-107"></i> dw-file-107
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-114"></i> dw-folder-114
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-115"></i> dw-folder-115
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-116"></i> dw-folder-116
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-108"></i> dw-file-108
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-109"></i> dw-file-109
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-110"></i> dw-file-110
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-117"></i> dw-folder-117
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-118"></i> dw-folder-118
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-119"></i> dw-folder-119
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-1111"></i> dw-file-1111
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-112"></i> dw-file-112
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-113"></i> dw-file-113
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-120"></i> dw-folder-120
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-121"></i> dw-folder-121
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-122"></i> dw-folder-122
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-114"></i> dw-file-114
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-115"></i> dw-file-115
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-116"></i> dw-file-116
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-123"></i> dw-folder-123
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-124"></i> dw-folder-124
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-125"></i> dw-folder-125
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-117"></i> dw-file-117
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-118"></i> dw-file-118
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-119"></i> dw-file-119
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-126"></i> dw-folder-126
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-127"></i> dw-folder-127
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-128"></i> dw-folder-128
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-120"></i> dw-file-120
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-1211"></i> dw-file-1211
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-122"></i> dw-file-122
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-129"></i> dw-folder-129
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-130"></i> dw-folder-130
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-131"></i> dw-folder-131
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-123"></i> dw-file-123
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-124"></i> dw-file-124
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-125"></i> dw-file-125
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-132"></i> dw-folder-132
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-133"></i> dw-folder-133
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-134"></i> dw-folder-134
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-126"></i> dw-file-126
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-127"></i> dw-file-127
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-128"></i> dw-file-128
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-135"></i> dw-folder-135
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-136"></i> dw-folder-136
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-137"></i> dw-folder-137
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-129"></i> dw-file-129
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-130"></i> dw-file-130
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-131"></i> dw-file-131
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-138"></i> dw-folder-138
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-139"></i> dw-folder-139
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-140"></i> dw-folder-140
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-132"></i> dw-file-132
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-133"></i> dw-file-133
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-134"></i> dw-file-134
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-141"></i> dw-folder-141
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-142"></i> dw-folder-142
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-143"></i> dw-folder-143
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-135"></i> dw-file-135
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-136"></i> dw-file-136
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-137"></i> dw-file-137
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-144"></i> dw-folder-144
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-145"></i> dw-folder-145
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-146"></i> dw-folder-146
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-138"></i> dw-file-138
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-139"></i> dw-file-139
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-140"></i> dw-file-140
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-147"></i> dw-folder-147
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-148"></i> dw-folder-148
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-149"></i> dw-folder-149
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-141"></i> dw-file-141
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-142"></i> dw-file-142
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-143"></i> dw-file-143
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-150"></i> dw-folder-150
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-151"></i> dw-folder-151
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-152"></i> dw-folder-152
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-144"></i> dw-file-144
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-file1"></i> dw-video-file1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-file-1"></i> dw-video-file-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-153"></i> dw-folder-153
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-154"></i> dw-folder-154
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-155"></i> dw-folder-155
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-file-2"></i> dw-video-file-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-145"></i> dw-file-145
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-146"></i> dw-file-146
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-156"></i> dw-folder-156
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-157"></i> dw-folder-157
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-158"></i> dw-folder-158
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-147"></i> dw-file-147
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-148"></i> dw-file-148
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-149"></i> dw-file-149
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-159"></i> dw-folder-159
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-160"></i> dw-folder-160
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-161"></i> dw-folder-161
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-150"></i> dw-file-150
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-151"></i> dw-file-151
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-152"></i> dw-file-152
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-162"></i> dw-folder-162
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-163"></i> dw-folder-163
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder-164"></i> dw-folder-164
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-153"></i> dw-file-153
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wifi2"></i> dw-wifi2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-webcam"></i> dw-webcam
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wallet1"></i> dw-wallet1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-view"></i> dw-view
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-video-camera2"></i>
										dw-video-camera2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user-12"></i> dw-user-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-link-3"></i> dw-link-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-upload2"></i> dw-upload2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-unlock"></i> dw-unlock
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-undo2"></i> dw-undo2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tick"></i> dw-tick
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-tag1"></i> dw-tag1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-suitcase2"></i> dw-suitcase2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-box-1"></i> dw-box-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-stop"></i> dw-stop
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sound"></i> dw-sound
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-slideshow"></i> dw-slideshow
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shuffle2"></i> dw-shuffle2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-share-11"></i> dw-share-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-share2"></i> dw-share2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-settings2"></i> dw-settings2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cursor-12"></i> dw-cursor-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shield1"></i> dw-shield1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-loupe"></i> dw-loupe
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-210"></i> dw-file-210
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-balance"></i> dw-balance
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-diskette2"></i> dw-diskette2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-hourglass1"></i> dw-hourglass1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ruler1"></i> dw-ruler1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-next-2"></i> dw-next-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pie-chart1"></i> dw-pie-chart1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-repeat-11"></i> dw-repeat-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-repeat1"></i> dw-repeat1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-refresh2"></i> dw-refresh2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-books"></i> dw-books
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-random1"></i> dw-random1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-user2"></i> dw-user2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-light-bulb"></i> dw-light-bulb
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flash-1"></i> dw-flash-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-export"></i> dw-export
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-pulse"></i> dw-pulse
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-next-1"></i> dw-next-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-piggy-bank"></i> dw-piggy-bank
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-dropper"></i> dw-dropper
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-smartphone2"></i> dw-smartphone2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-message-1"></i> dw-message-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-paint-bucket1"></i>
										dw-paint-bucket1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file-154"></i> dw-file-154
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bell1"></i> dw-bell1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-clipboard1"></i> dw-clipboard1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-newspaper-1"></i> dw-newspaper-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-newspaper"></i> dw-newspaper
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-antenna1"></i> dw-antenna1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bar-chart1"></i> dw-bar-chart1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mute-1"></i> dw-mute-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-music-1"></i> dw-music-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-sound-waves"></i> dw-sound-waves
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-music"></i> dw-music
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-film"></i> dw-film
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-move-1"></i> dw-move-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-move2"></i> dw-move2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mouse"></i> dw-mouse
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-more2"></i> dw-more2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-mute"></i> dw-mute
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-microphone-11"></i>
										dw-microphone-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-microphone1"></i> dw-microphone1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-message"></i> dw-message
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map-12"></i> dw-map-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-placeholder"></i> dw-placeholder
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-low-battery"></i> dw-low-battery
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-map2"></i> dw-map2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-link-2"></i> dw-link-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-like1"></i> dw-like1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-layers1"></i> dw-layers1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-key2"></i> dw-key2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-image-12"></i> dw-image-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-image2"></i> dw-image2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-link-1"></i> dw-link-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-home"></i> dw-home
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-headphones-1"></i> dw-headphones-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-headphones1"></i> dw-headphones1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-focus1"></i> dw-focus1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fast-forward-1"></i>
										dw-fast-forward-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-folder3"></i> dw-folder3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flash1"></i> dw-flash1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-flag2"></i> dw-flag2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-filter2"></i> dw-filter2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-fast-forward"></i> dw-fast-forward
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-exit"></i> dw-exit
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-expand2"></i> dw-expand2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-email2"></i> dw-email2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-edit3"></i> dw-edit3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-dvd1"></i> dw-dvd1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-download2"></i> dw-download2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-down-arrow3"></i> dw-down-arrow3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-file4"></i> dw-file4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-delete-3"></i> dw-delete-3
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-delete-2"></i> dw-delete-2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-delete-1"></i> dw-delete-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-browser-1"></i> dw-browser-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cursor2"></i> dw-cursor2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-crop1"></i> dw-crop1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat-21"></i> dw-chat-21
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cloud1"></i> dw-cloud1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-wall-clock2"></i> dw-wall-clock2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-checked"></i> dw-checked
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat-12"></i> dw-chat-12
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-chat4"></i> dw-chat4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-link4"></i> dw-link4
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-cctv1"></i> dw-cctv1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shopping-cart2"></i>
										dw-shopping-cart2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-photo-camera-1"></i>
										dw-photo-camera-1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-photo-camera2"></i>
										dw-photo-camera2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-calendar2"></i> dw-calendar2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bug2"></i> dw-bug2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-browser1"></i> dw-browser1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-broken"></i> dw-broken
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-brightness1"></i> dw-brightness1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-box"></i> dw-box
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bookmark2"></i> dw-bookmark2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-book2"></i> dw-book2
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-board"></i> dw-board
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-bluetooth"></i> dw-bluetooth
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-alarm"></i> dw-alarm
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-battery-11"></i> dw-battery-11
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-battery1"></i> dw-battery1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-ban"></i> dw-ban
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-shopping-bag1"></i>
										dw-shopping-bag1
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-delete"></i> dw-delete
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-next"></i> dw-next
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-megaphone"></i> dw-megaphone
									</a>
								</div>
								<div
									class="fa-hover col-md-3 col-sm-6 col-12"
									data-toggle="tooltip"
									data-placement="bottom"
									title="Click To Copy Code"
								>
									<a href="javascript:;">
										<i class="icon-copy dw dw-add"></i> dw-add
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="footer-wrap pd-20 mb-20 card-box">
					DeskApp - Bootstrap 4 Admin Template By
					<a href="https://github.com/dropways" target="_blank"
						>Ankit Hingarajiya</a
					>
				</div>
			</div>
		</div>
		<!-- welcome modal start -->
		<div class="welcome-modal">
			<button class="welcome-modal-close">
				<i class="bi bi-x-lg"></i>
			</button>
			<iframe
				class="w-100 border-0"
				src="https://embed.lottiefiles.com/animation/31548"
			></iframe>
			<div class="text-center">
				<h3 class="h5 weight-500 text-center mb-2">
					Open source
					<span role="img" aria-label="gratitude">❤️</span>
				</h3>
				<div class="pb-2">
					<a
						class="github-button"
						href="https://github.com/dropways/deskapp"
						data-color-scheme="no-preference: dark; light: light; dark: light;"
						data-icon="octicon-star"
						data-size="large"
						data-show-count="true"
						aria-label="Star dropways/deskapp dashboard on GitHub"
						>Star</a
					>
					<a
						class="github-button"
						href="https://github.com/dropways/deskapp/fork"
						data-color-scheme="no-preference: dark; light: light; dark: light;"
						data-icon="octicon-repo-forked"
						data-size="large"
						data-show-count="true"
						aria-label="Fork dropways/deskapp dashboard on GitHub"
						>Fork</a
					>
				</div>
			</div>
			<div class="text-center mb-1">
				<div>
					<a
						href="https://github.com/dropways/deskapp"
						target="_blank"
						class="btn btn-light btn-block btn-sm"
					>
						<span class="text-danger weight-600">STAR US</span>
						<span class="weight-600">ON GITHUB</span>
						<i class="fa fa-github"></i>
					</a>
				</div>
				<script
					async
					defer="defer"
					src="https://buttons.github.io/buttons.js"
				></script>
			</div>
			<a
				href="https://github.com/dropways/deskapp"
				target="_blank"
				class="btn btn-success btn-sm mb-0 mb-md-3 w-100"
			>
				DOWNLOAD
				<i class="fa fa-download"></i>
			</a>
			<p class="font-14 text-center mb-1 d-none d-md-block">
				Available in the following technologies:
			</p>
			<div class="d-none d-md-flex justify-content-center h1 mb-0 text-danger">
				<i class="fa fa-html5"></i>
			</div>
		</div>
		<button class="welcome-modal-btn">
			<i class="fa fa-download"></i> Download
		</button>
		<!-- welcome modal end -->
		<!-- js -->
		<script src="vendors/scripts/core.js"></script>
		<script src="vendors/scripts/script.min.js"></script>
		<script src="vendors/scripts/process.js"></script>
		<script src="vendors/scripts/layout-settings.js"></script>
		<!-- Google Tag Manager (noscript) -->
		<noscript
			><iframe
				src="https://www.googletagmanager.com/ns.html?id=GTM-NXZMQSS"
				height="0"
				width="0"
				style="display: none; visibility: hidden"
			></iframe
		></noscript>
		<!-- End Google Tag Manager (noscript) -->
	</body>
</html>
